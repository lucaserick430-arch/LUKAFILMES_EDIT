const Database = require("better-sqlite3");

const db = new Database("banco.db");

db.exec(`
    CREATE TABLE IF NOT EXISTS usuarios (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        usuario TEXT UNIQUE NOT NULL,
        senha TEXT NOT NULL,
        status TEXT NOT NULL DEFAULT 'ativo',
        tipo TEXT NOT NULL DEFAULT 'usuario',
        criado_em DATETIME DEFAULT CURRENT_TIMESTAMP
    )
`);

console.log("Banco de dados criado com sucesso!");

db.close();